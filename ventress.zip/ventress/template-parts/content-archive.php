<article class="articleContainer">
    <h3 class="articleHeader">
        <a href="<?php the_permalink() ?>"
            ><?php the_title(); ?></a
        >
    </h3>
    <div class="articleContent">
        <?php the_excerpt(); ?>
    </div>
</article>
