<form action="/" method="get">
	<input type="text" name="s" placeholder="Search santhaname.com" value="<?php the_search_query(); ?>" />
</form>
